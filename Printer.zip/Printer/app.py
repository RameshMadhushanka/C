import os
import base64
from io import BytesIO
import flask
from flask import Flask, render_template, redirect, url_for, flash, session, abort
from flask_mqtt import Mqtt
from werkzeug.security import generate_password_hash, check_password_hash
import werkzeug.utils
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, current_user
from flask_bootstrap import Bootstrap
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField
from wtforms.validators import Required, Length, EqualTo
import onetimepass
import pyqrcode

import string
import random
import json
import png

from datetime import datetime
import webbrowser
import time

qr_cv = 0
qrdata = 0
name = 0

UPLOAD_FOLDER = './uploaded_files'
ALLOWED_EXTENSIONS = {'txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif', 'HEIC'}

# create application instance
app = Flask(__name__)
app.config.from_object('config')
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MQTT_BROKER_URL'] = '20.198.176.230' 
app.config['MQTT_BROKER_PORT'] = 1883
app.config['MQTT_USERNAME'] = 'admin' 
app.config['MQTT_PASSWORD'] = 'admin@123' 
app.config['MQTT_REFRESH_TIME'] = 1.0
mqtt = Mqtt(app)


bootstrap = Bootstrap(app)
db = SQLAlchemy(app)
lm = LoginManager(app)

def allowed_file(filename):
    """
    Check if someone is not trying to send a php file or something, 
    like that, this could harm the server
    """
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def id_generator(size=10, chars=string.ascii_uppercase + string.digits):
    global qrdata
    qrdata = ''.join(random.choice(chars) for _ in range(size))
    return qrdata

def get_uri():
    data = {
        "data": id_generator()
    }
    return (json.dumps(data))

def send_mail():
    import smtplib
    from email.mime.multipart import MIMEMultipart
    from email.mime.text import MIMEText
    from email.mime.image import MIMEImage
    mail= MIMEMultipart()

    sender_email = "send@gmail.com" 
    rec_email = "rec@gmail.com" 
    password = "" 
    
    server = smtplib.SMTP('smtp.gmail.com', 587)
    server.starttls()
    server.login(sender_email, password)

    mail['From']='QR Code For Secure Print'
    mail['To'] = rec_email
    mail['Subject']='QR-Code'

    fp = open('qr.png', 'rb')
    msgImage = MIMEImage(fp.read())
    fp.close()

    msgImage.add_header('Content-ID', '<image1>')
    mail.attach(msgImage)

    server.sendmail(sender_email, rec_email, mail.as_string())

class User(UserMixin, db.Model):
    """User model."""
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), index=True)
    email = db.Column(db.String(512))
    password_hash = db.Column(db.String(128))
    otp_secret = db.Column(db.String(16))

    def __init__(self, **kwargs):
        super(User, self).__init__(**kwargs)
        if self.otp_secret is None:
            # generate a random secret
            self.otp_secret = base64.b32encode(os.urandom(10)).decode('utf-8')

    @property
    def password(self):
        raise AttributeError('password is not a readable attribute')

    @password.setter
    def password(self, password):
        self.password_hash = generate_password_hash(password)

    def verify_password(self, password):
        return check_password_hash(self.password_hash, password)

    def get_totp_uri(self):
        return 'otpauth://totp/2FA-Demo:{0}?secret={1}&issuer=2FA-Demo'.format(self.username, self.otp_secret)

    def verify_totp(self, token):
        return onetimepass.valid_totp(token, self.otp_secret)

    def get_mail(self, email):
        return self.email == email

class Printers(db.Model):
    """printers model."""
    __tablename__ = 'printers'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), index=True)
    date = db.Column(db.String(64), index=True)
    time = db.Column(db.String(64), index=True)

@lm.user_loader
def load_user(user_id):
    """User loader callback for Flask-Login."""
    return User.query.get(int(user_id))

@mqtt.on_connect()
def handle_connect(client, userdata, flags, rc):
    mqtt.subscribe('qr_data')

@mqtt.on_message()
def handle_mqtt_message(client, userdata, message):
    global qr_cv
    topic = message.topic
    if topic == 'qr_data':
        data = message.payload.decode()
        qr_data = json.loads(data)
        qr_cv = qr_data["qr"]

class RegisterForm(FlaskForm):
    """Registration form."""
    username = StringField('Username', validators=[Required(), Length(1, 64)])
    email = StringField('Email', validators=[Required(), Length(1, 128)])
    password = PasswordField('Password', validators=[Required()])
    password_again = PasswordField('Password again', validators=[Required(), EqualTo('password')])
    submit = SubmitField('Register')

class LoginForm(FlaskForm):
    """Login form."""
    username = StringField('Username', validators=[Required(), Length(1, 64)])
    email = StringField('Email', validators=[Required(), Length(1, 128)])
    password = PasswordField('Password', validators=[Required()])
    token = StringField('Token', validators=[Required(), Length(6, 6)])
    submit = SubmitField('Login')

@app.route('/', methods=['GET', 'POST'])
def index():

    if flask.request.method == 'GET':
        return flask.render_template("index.html")

    if flask.request.method == 'POST':
        global qr_cv
        global name
        
        # check if the post request has the file part
        if 'file' not in flask.request.files:
            return flask.render_template("oops.html")

        print(qr_cv, qrdata)
        if qrdata != qr_cv:
            return flask.render_template("oops.html")

        file = flask.request.files['file']
        # if user does not select file, browser also
        # submit an empty part without filename
        if file.filename == '':
            return flask.render_template("oops.html")
        if file and allowed_file(file.filename) and (qrdata == qr_cv):
            filename = werkzeug.utils.secure_filename(file.filename)
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
            filepath = UPLOAD_FOLDER + "/" + filename

            import cups
            conn = cups.Connection ()
            printers = conn.getPrinters ()
            for printer in printers:
                print (printer, printers[printer]["device-uri"])
                conn.printFile(printer,'filepath',"",{})
                print('Done')

            now = datetime.now()
            date= now.strftime("%d/%m/%Y")
            time = now.strftime("%H:%M:%S")
            printers = Printers(username=name, date=date, time=time)
            db.session.add(printers)
            db.session.commit()

            return flask.render_template("printed.html")

        return flask.render_template("index.html")

@app.route("/secure", methods=['POST'])
def move_forward():
    send_mail()
    forward_message = "QR code send to your mail..."
    return flask.render_template('index.html', forward_message=forward_message)

@app.route('/register', methods=['GET', 'POST'])
def register():
    """User registration route."""
    if current_user.is_authenticated:
        # if user is logged in we get out of here
        return redirect(url_for('index'))
    form = RegisterForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user is not None:
            flash('Username already exists.')
            return redirect(url_for('register'))
        # add new user to the database
        user = User(username=form.username.data, email=form.email.data, password=form.password.data)
        db.session.add(user)
        db.session.commit()

        # redirect to the two-factor auth page, passing username in session
        session['username'] = user.username
        session['email'] = user.email
        return redirect(url_for('two_factor_setup'))
    return render_template('register.html', form=form)

@app.route('/twofactor')
def two_factor_setup():
    if 'username' not in session:
        return redirect(url_for('index'))
    user = User.query.filter_by(username=session['username']).first()
    if user is None:
        return redirect(url_for('index'))
    # since this page contains the sensitive qrcode, make sure the browser
    # does not cache it
    return render_template('two-factor-setup.html'), 200, {
        'Cache-Control': 'no-cache, no-store, must-revalidate',
        'Pragma': 'no-cache',
        'Expires': '0'}

@app.route('/qrcode')
def qrcode():
    if 'username' not in session:
        abort(404)
    user = User.query.filter_by(username=session['username']).first()
    if user is None:
        abort(404)

    # for added security, remove username and email from session
    del session['username']

    # render qrcode for FreeTOTP
    url = pyqrcode.create(user.get_totp_uri())
    stream = BytesIO()
    url.svg(stream, scale=3)
    return stream.getvalue(), 200, {
        'Content-Type': 'image/svg+xml',
        'Cache-Control': 'no-cache, no-store, must-revalidate',
        'Pragma': 'no-cache',
        'Expires': '0'}

@app.route('/qrcv')
def qrcv():
    url = pyqrcode.create(get_uri())
    url.png('qr.png', scale= 6)
    stream = BytesIO()
    url.svg(stream, scale= 6)
    return stream.getvalue(), 200, {
        'Content-Type': 'image/svg+xml',
        'Cache-Control': 'no-cache, no-store, must-revalidate',
        'Pragma': 'no-cache',
        'Expires': '0'}

@app.route('/login', methods=['GET', 'POST'])
def login():
    """User login route."""
    if current_user.is_authenticated:
        # if user is logged in we get out of here
        return redirect(url_for('index'))
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user is None or not user.verify_password(form.password.data) or not user.verify_totp(form.token.data) or not user.get_mail(form.email.data):
            flash('Invalid username, email, password or token.')
            return redirect(url_for('login'))
        
        if user is not None and user.verify_password(form.password.data):
            global name
            name = (user.username)

        # log user in
        login_user(user)
        flash('You are now logged in!')
        return redirect(url_for('index'))
    return render_template('login.html', form=form)

@app.route('/logout')
def logout():
    """User logout route."""
    logout_user()
    return redirect(url_for('index'))

# create database tables if they don't exist yet
db.create_all()

if __name__ == '__main__':
    app.run(host = '0.0.0.0', port = 8080)