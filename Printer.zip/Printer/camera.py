import cv2
import sys
from flask import Flask, render_template, Response
from webcamvideostream import WebcamVideoStream
from flask_basicauth import BasicAuth
import time
import threading

import paho.mqtt.client as mqtt
import os
import json
import random
import numpy as np
import pyzbar.pyzbar as pyzbar

app = Flask(__name__)
app.config['BASIC_AUTH_USERNAME'] = 'admin'
app.config['BASIC_AUTH_PASSWORD'] = 'admin123'
app.config['BASIC_AUTH_FORCE'] = True

basic_auth = BasicAuth(app)
last_epoch = 0
qr_cv = 0

def on_message(client, obj, msg):
    print(msg.topic + " " + str(msg.qos) + " " + str(msg.payload))

def on_publish(client, obj, mid):
    print("mid: " + str(mid))

try:
    mqttc = mqtt.Client()
    mqttc.on_message = on_message
    mqttc.on_publish = on_publish

    mqttc.username_pw_set("admin", "admin@123")
    mqttc.connect('20.198.176.230', 1883, 60)
    print("Conected to MQTT Brocker")

except:
    print("Not Conected to MQTT Brocker")
    exit

def qr_data(frame):
    global qr_cv

    # image = cv2.imread("qr.png")
    decodedObjects = pyzbar.decode(frame)
    for obj in decodedObjects:
        cv_data = json.loads(obj.data)
        qr_cv = cv_data["data"]

@app.route('/')
@basic_auth.required
def index():
    return render_template('index.html')

def gen(camera):
    while True:
        global qr_cv

        if camera.stopped:
            break
        frame = camera.read()

        qr_data(frame)
        qr = {
            "qr": qr_cv
        }

        ret, jpeg = cv2.imencode('.jpg',frame)
        if jpeg is not None:
            mqttc.publish("qr_data", (json.dumps(qr)))
            print('published', qr_cv)
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + jpeg.tobytes() + b'\r\n\r\n')
        else:
            print("frame is none")

@app.route('/video_feed')
def video_feed():
    return Response(gen(WebcamVideoStream().start()),
                    mimetype='multipart/x-mixed-replace; boundary=frame')

if __name__ == '__main__':
    app.run(host = '0.0.0.0', port = 5000)