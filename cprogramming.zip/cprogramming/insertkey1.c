#include<stdio.h>

main()
{

    int a;
    int b;
    char f;
    char g;
    float e;
    scanf("%d",&a);
    scanf("%d",&b);
    scanf("%s",&f);
    scanf("%s",&g);
    scanf("%f",&e);

     printf("%d\n",a);
     printf("%d\n",b);
     printf("%c\n",f);
     printf("%c\n",g);
     printf("%f\n",e);
}


