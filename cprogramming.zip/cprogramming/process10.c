#include<stdio.h>
main()
{
    float p,b; int q;
    printf("Input item rs");

    scanf("%f",&p);
     printf("enter qty 1\t");
    scanf("%d",&q);
    b=q*p;
    printf(" rs %f",b);


}
