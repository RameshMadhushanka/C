#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("Hello world!\n");
    printf("cprogramming\n");
    printf("NIBM");

    int A;
    A=70;
    printf("%d",A);
    int x; float y;
    x=70;
    y=9.90;
    printf("%d\t",x);
    printf("%f",y);
    char d;
    d="isuru";
    printf("%c",d);

    return 0;
}
