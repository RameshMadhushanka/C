#include<stdio.h>
main()
{
    int ar[2];
    scanf("%d",&ar[0]);
    printf("%d",ar[0]);
}
