#include<stdio.h>

main()
{

    int a,b; char f,ds; float e;
    scanf("%d\n",&a);
    scanf("%d\n",&b);
    scanf("%c\n",&f);
    scanf("%c\n",&ds);
    scanf("%f",&e);

     printf("%d\n",a);
     printf("%d\n",b);
     printf("%c\n",f);
     printf("%c\n",ds);
     printf("%f",e);
}

