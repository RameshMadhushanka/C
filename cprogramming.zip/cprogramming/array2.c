
#include<stdio.h>
main()
{
    int x[5];
    x[0]=1;
    x[1]=2;
    x[2]=3;
    x[3]=4;
    x[4]=5;
    printf("%d\n",x[0]);
    printf("%d\n",x[1]);
    printf("%d\n",x[2]);
    printf("%d\n",x[3]);
    printf("%d",x[4]);

}
