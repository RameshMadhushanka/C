
#include<stdio.h>main()
main()
{
    int x,y,z;
    x=5;
    y=10;
    z=5;

    printf("%d \t",++z-x+++--y);



}
