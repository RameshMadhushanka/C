#include<stdio.h>
main()
{
    float c,f;
    printf("Input celsiyas\t");

    scanf("%f",&c);
    f=(c*9/5)+32;

    printf(" anser is %f",f);


}

