
#include<stdio.h>
main()
{
    int x[5];
    scanf("%d\n",&x[0]);
    scanf("%d\n",&x[1]);
    scanf("%d\n",&x[2]);
    scanf("%d\n",&x[3]);
    scanf("%d",&x[4]);

    printf("%d\n",x[0]);
    printf("%d\n",x[1]);
    printf("%d\n",x[2]);
    printf("%d\n",x[3]);
    printf("%d",x[4]);

}
