
#include<stdio.h>main()
main()
{
    float x,y,z ,a, b;
    printf("enter no 1\t");
    scanf("%f",&x);
     printf("enter no 2\t");
    scanf("%f",&y);
     printf("enter no 3\t");
    scanf("%f",&z);
    a=x+y+z;
    b=a/3;

     printf("total is %f \t",a);
     printf("avarage is %f",b);
}
