#include<stdio.h>
main()
{
   int x;


    scanf("%d",&x);
  if(x>100)
    {
        printf("A");
    }




}

