
#include<stdio.h>

main()
{
    printf("cprogrammeing\n");
    printf("NIBM");
}
