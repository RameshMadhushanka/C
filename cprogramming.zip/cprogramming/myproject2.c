
#include<stdio.h>

main()
{
    printf("cprogramming\n");
    printf("NIBM\n");

    int A;
    A=70;
    printf("%d\t",A);
    int x; float y;
    x=71;
    y=9.90;
    printf("%d\t",x);
    printf("%f\t",y);
    char d;
    d='a';
    printf("%c\t",d);


}
