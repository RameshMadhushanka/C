
#include<stdio.h>main()
main()
{
    int x,y;
    x=4;
    y=10;
    x++;
    y--;
    printf("%d \t",++x);
    printf("%d\t",--y);


}
