#include<stdio.h>
main()
{
    int x,y,z;
    printf("enter no 1\t");
    scanf("%d",&x);
     printf("enter no 2\t");
    scanf("%d",&y);
    z=x*y;
     printf("total is %d",z);
}
