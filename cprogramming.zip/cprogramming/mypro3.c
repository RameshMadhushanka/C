
#include<stdio.h>

main()
{
    printf("isuru\n");
    int x,y; char c,d; float e;
     x=500;
     y=150;
     c='D';
     d='K';
     e=2.5;
    printf("%d\n",x);
    printf("%d\n",y);
    printf("%c\n",c);
    printf("%c\n",d);
    printf("%f\n",e);

}
