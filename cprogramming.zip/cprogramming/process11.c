#include<stdio.h>
main()
{
    float k,s; int t;
    printf("Input distance\t");

    scanf("%f",&k);
     printf("input hours \t");
    scanf("%d",&t);
    s=k/t;
    printf(" anser is %f kms-1",s);


}

